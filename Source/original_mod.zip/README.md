﻿# Repair Work Type

Adds the Repair work type in the Work tab.

Repairing task has been removed from Construction and put in Repair intead.

Maintenance task from Fluffy's Breakdown mod has been removed from Construction and put in repair instead.

Note : You can safely remove or add this mod to any save, as it is only patches things from the core mod through Defs.

Note 2 : You don't need Fluffy's Breakdown mod to use this mod ; it will only shows a few errors when you load a save and do nothing afterward if you don't have it.

### Thanks

Special thanks to kaptain_kavern for his mod "Corrected WorkGivers" which I took the orginal code from and modified it to my taste.
